//
//  CGFloat+Extension.swift
//  AromAI
//
//  Created by Emir Keleş on 2.05.2024.
//

import Foundation

extension CGFloat {
    static let bottomTabHeight = CGFloat(120.0)
}
