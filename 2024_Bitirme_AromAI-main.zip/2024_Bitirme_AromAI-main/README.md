# Bitirme_AromAI
Marmara Üniversitesi Teknoloji Fakültesi Bilgisayar Mühendisliği Bitirme Projesi
